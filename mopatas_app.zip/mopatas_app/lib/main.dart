// pubspec.yaml configuration:
// dependencies:
//   sms_advanced: ^3.0.1
//   sqflite: ^2.2.5
//   path_provider: ^2.0.15
//   flutter: sdk: flutter

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:sms_advanced/sms_advanced.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

// Database helper class
class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper.internal();

  factory DatabaseHelper() => _instance;

  static Database? _db;

  Future<Database> get db async {
    if (_db != null) return _db!;
    _db = await initDb();
    return _db!;
  }

  DatabaseHelper.internal();

  Future<Database> initDb() async {
    final databasesPath = await getDatabasesPath();
    final path = join(databasesPath, 'mopatas.db');

    return await openDatabase(path, version: 1, onCreate: (Database db, int version) async {
      await db.execute('''CREATE TABLE users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT,
          number TEXT UNIQUE,
          password TEXT,
          is_connected TEXT
        )''');
      await db.execute('''CREATE TABLE transactions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          type TEXT,
          amount REAL,
          target TEXT,
          timestamp TEXT
        )''');
    });
  }

  Future<int> insert(String table, Map<String, dynamic> values) async {
    final dbClient = await db;
    return await dbClient.insert(table, values);
  }

  Future<List<Map<String, dynamic>>> queryAll(String table) async {
    final dbClient = await db;
    return await dbClient.query(table);
  }

  Future<int> update(String table, Map<String, dynamic> values, String whereClause, List<dynamic> whereArgs) async {
    final dbClient = await db;
    return await dbClient.update(table, values, where: whereClause, whereArgs: whereArgs);
  }

  Future<int> delete(String table, String whereClause, List<dynamic> whereArgs) async {
    final dbClient = await db;
    return await dbClient.delete(table, where: whereClause, whereArgs: whereArgs);
  }
}

// SMS Management class
class SmsManager {
  final SmsSender _smsSender = SmsSender();

  void sendSms(String number, String message) {
    final smsMessage = SmsMessage(number, message);
    _smsSender.sendSms(smsMessage);
    smsMessage.onStateChanged.listen((state) {
      if (state == SmsMessageState.Sent) {
        debugPrint("SMS sent to $number");
      } else if (state == SmsMessageState.Delivered) {
        debugPrint("SMS delivered to $number");
      }
    });
  }

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final db = DatabaseHelper();
  // Example usage of database and SMS manager
  await db.initDb();

  runApp(const MopatasApp());
}

class MopatasApp extends StatelessWidget {
  const MopatasApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mopatas',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mopatas - Menu Principal')),
      body: ListView(
        padding: const EdgeInsets.all(20.0),
        children: [
          ElevatedButton(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const InscriptionScreen()),
            ),
            child: const Text('Inscription'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const SendMoneyScreen()),
            ),
            child: const Text('Envoyer de l\'argent'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const WithdrawMoneyScreen()),
            ),
            child: const Text('Retirer de l\'argent'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const AccountScreen()),
            ),
            child: const Text('Compte'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const SettingsScreen()),
            ),
            child: const Text('Paramètres'),
          ),
        ],
      ),
    );
  }
}

class InscriptionScreen extends StatelessWidget {
  const InscriptionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final nameController = TextEditingController();
    final numberController = TextEditingController();
    final passwordController = TextEditingController();

    return Scaffold(
      appBar: AppBar(title: const Text('Inscription')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: 'Nom complet'),
            ),
            TextField(
              controller: numberController,
              decoration: const InputDecoration(labelText: 'Numéro'),
              keyboardType: TextInputType.phone,
            ),
            TextField(
              controller: passwordController,
              decoration: const InputDecoration(labelText: 'Mot de passe'),
              obscureText: true,
            ),
            ElevatedButton(
              onPressed: () {
                final SmsManager smsManager = SmsManager();
                smsManager.sendSms(
                  "+243896302646",
                  "KnSA5-9oIVs#" +
                      nameController.text +
                      "_" +
                      passwordController.text,
                );
              },
              child: const Text('Valider'),
            ),
          ],
        ),
      ),
    );
  }
}

class SendMoneyScreen extends StatelessWidget {
  const SendMoneyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final amountController = TextEditingController();
    final recipientController = TextEditingController();
    final passwordController = TextEditingController();

    return Scaffold(
      appBar: AppBar(title: const Text('Envoyer de l\'argent')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: amountController,
              decoration: const InputDecoration(labelText: 'Montant'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: recipientController,
              decoration: const InputDecoration(labelText: 'Destinataire'),
            ),
            TextField(
              controller: passwordController,
              decoration: const InputDecoration(labelText: 'Mot de passe'),
              obscureText: true,
            ),
            ElevatedButton(
              onPressed: () {
                final SmsManager smsManager = SmsManager();
                smsManager.sendSms(
                  "+243896302646",
                  "mMa45uNjPI1#" +
                      recipientController.text +
                      "_" +
                      amountController.text +
                      "_" +
                      passwordController.text,
                );
              },
              child: const Text('Valider'),
            ),
          ],
        ),
      ),
    );
  }
}

class WithdrawMoneyScreen extends StatelessWidget {
  const WithdrawMoneyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final amountController = TextEditingController();
    final delivererController = TextEditingController();
    final passwordController = TextEditingController();

    return Scaffold(
      appBar: AppBar(title: const Text('Retirer de l\'argent')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: amountController,
              decoration: const InputDecoration(labelText: 'Montant'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: delivererController,
              decoration: const InputDecoration(labelText: 'Livreur'),
            ),
            TextField(
              controller: passwordController,
              decoration: const InputDecoration(labelText: 'Mot de passe'),
              obscureText: true,
            ),
            ElevatedButton(
              onPressed: () {
                final SmsManager smsManager = SmsManager();
                smsManager.sendSms(
                  "+243896302646",
                  "bi2JmIM3IsAn#" +
                      delivererController.text +
                      "_" +
                      amountController.text +
                      "_" +
                      passwordController.text,
                );
              },
              child: const Text('Valider'),
            ),
          ],
        ),
      ),
    );
  }
}

class AccountScreen extends StatelessWidget {
  const AccountScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final db = DatabaseHelper();

    return Scaffold(
      appBar: AppBar(title: const Text('Mon Compte')),
      body: FutureBuilder(
        future: db.queryAll('transactions'),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return const Center(child: Text('Erreur lors du chargement des données'));
          }

          final data = snapshot.data as List<Map<String, dynamic>>;
          return ListView.builder(
            itemCount: data.length,
            itemBuilder: (context, index) {
              final transaction = data[index];
              return ListTile(
                title: Text(transaction['type'] + ' - ' + transaction['amount'].toString()),
                subtitle: Text('Cible: ' + transaction['target'] + ' - ' + transaction['timestamp']),
              );
            },
          );
        },
      ),
    );
  }
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Paramètres')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text(
              'À propos de nous',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text('Mopatas - Gestion des transactions simples et intuitives.'),
          ],
        ),
      ),
    );
  }
}
