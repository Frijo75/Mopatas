import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static Database? _database;

  Future<Database> get database async {
    if (_database == null) {
      _database = await initDB();
    }
    return _database!;
  }

  Future<Database> initDB() async {
    String path = join(await getDatabasesPath(), 'mopatas.db');
    return await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''
      CREATE TABLE user (
        id INTEGER PRIMARY KEY,
        name TEXT,
        phone TEXT,
        password TEXT,
        user_connect TEXT
      )
      ''');
      await db.execute('''
      CREATE TABLE solde (
        id INTEGER PRIMARY KEY,
        montant INTEGER,
        type TEXT,
        heure TEXT
      )
      ''');
    });
  }

  Future<void> insertUser(String name, String phone, String password, String userConnect) async {
    final db = await database;
    await db.insert('user', {'name': name, 'phone': phone, 'password': password, 'user_connect': userConnect});
  }

  // Ajoutez d'autres méthodes pour insérer, mettre à jour et récupérer des données
}
